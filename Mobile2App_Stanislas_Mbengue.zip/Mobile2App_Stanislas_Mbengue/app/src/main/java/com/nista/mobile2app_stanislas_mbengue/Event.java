package com.nista.mobile2app_stanislas_mbengue;

import java.util.Date;

public class Event {
    private int id;
    private String eventName;
    private String description;
    private String eventDate;

    public Event() {
    }

    public Event(int id, String eventName, String description, String eventDate) {
        this.id = id;
        this.eventName = eventName;
        this.description = description;
        this.eventDate = eventDate;
    }
    public Event(String eventName, String description, String eventDate) {
        this.eventName = eventName;
        this.description = description;
        this.eventDate = eventDate;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }
}
