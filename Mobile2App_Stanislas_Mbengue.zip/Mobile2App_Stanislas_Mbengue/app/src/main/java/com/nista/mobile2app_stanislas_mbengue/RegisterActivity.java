package com.nista.mobile2app_stanislas_mbengue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class RegisterActivity extends AppCompatActivity {

    private EditText username;
    private EditText email;
    private EditText  password;
    private EditText confirmPassword;
    private TextView errorPasswordMatching;
    private Button registerButton;
    private TextView alreadyMember;

    private UserDatabase userDatabase;
    private User user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //initialize the views
        username = findViewById(R.id.editTextName);
        email = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        confirmPassword = findViewById(R.id.editTextTextComfirmPassword);
        errorPasswordMatching = findViewById(R.id.textViewErrorMatchingPassword);
        registerButton = findViewById(R.id.registerButton);
        alreadyMember = findViewById(R.id.textViewAlreadyMember);


        //initialize the database and user
        user = new User();
        userDatabase = new UserDatabase(RegisterActivity.this);


        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUserToDatabase();
                emptyInputEditText();

                Toast.makeText(RegisterActivity.this, "You have successfully register!", Toast.LENGTH_LONG );

                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        alreadyMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }

    private boolean  validateData() {
        boolean isValid = true;
        if(isEmpty(username) || username.length() < 2){
            isValid = false;
            username.setError("You must enter your full name to register");
        }
        if(!isValidEmail(email)){
            isValid = false;
            email.setError("Please enter a valid email!");
        }
        if(isValidPassword(password) || password.length() < 8){
            isValid = false;
            password.setError("Your password must be at least 8 character long!");
        }
        if(isValidPassword(confirmPassword) || confirmPassword.length() < 8 && confirmPassword == password){
            isValid = false;
            confirmPassword.setError("Your password does not much!");
            errorPasswordMatching.setText("Your password does not macth");
        }
        if(! isValid){
            Toast toast = Toast.makeText(this, "You have entered incorrect value!", Toast.LENGTH_LONG);
            return false;
        }else{
            return true;
        }

    }

    //check if user entered data are valid
    boolean isEmpty(EditText text){
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
    //check if the email is valid
    boolean isValidEmail(EditText text){
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }
    //check if password is valid
    boolean isValidPassword(EditText text){
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }

    private void registerUserToDatabase(){
        //called validate user data
        validateData();

        //check if email already exist in the database before adding a new user.
        if(!userDatabase.checkUser(email.getText().toString().trim())){
            //set user data
            user.setName(username.getText().toString().trim());
            user.setEmail(email.getText().toString().trim());
            user.setPassword(password.getText().toString().trim());

            //add user to the database
            userDatabase.addUser(user);

            Toast toast = Toast.makeText(this, "You have successfully register", Toast.LENGTH_LONG);
            toast.show();
        }else{
            Toast toast = Toast.makeText(this, "Register was unsuccessful, please verify that your data are correct!", Toast.LENGTH_LONG);
            toast.show();
        }
    }

    /**
     * empty all input edit text
     */
    private void emptyInputEditText() {
        username.setText(null);
        email.setText(null);
        password.setText(null);
        confirmPassword.setText(null);
    }

}