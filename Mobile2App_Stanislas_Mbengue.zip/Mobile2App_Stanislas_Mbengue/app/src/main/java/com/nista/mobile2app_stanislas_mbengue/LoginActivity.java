package com.nista.mobile2app_stanislas_mbengue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class LoginActivity extends AppCompatActivity {
    private final AppCompatActivity activity = LoginActivity.this;
    private EditText username;
    private EditText password;
    private TextView registerLink;
    private Button login;

    private UserDatabase userDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userDatabase = new UserDatabase(activity);
        InitializeComponent();
        setUpLoginListener();

    }


    private void InitializeComponent() {
        username = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);
        registerLink = findViewById(R.id.registerTextView);
        login = findViewById(R.id.signInbutton);
    }


    //register the login button listener
    private void setUpLoginListener() {
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //checkUserData();
                Intent intent = new Intent(LoginActivity.this, ListEventsActivity.class);
                startActivity(intent);
            }
        });
        //register the register textViewListener
        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
    //check if user entered valid data
    private void checkUserData() {
        boolean isValid = true;

        if(isEmpty(username)) {
            username.setError("You must enter your email test to login");
            isValid = false;
        }else if(!isEmail(username)){
            username.setError("Please enter a valid email");
            isValid = false;
        }

        if(isEmpty(password)){
            password.setError("You must enter your password to login");
            isValid = false;
        }else if( password.getText().toString().length() < 8 ){
            password.setError("Password must be at least 4 characters long!");
            isValid = false;
        }

        if(isValid){
            String usernameValue = username.getText().toString();
            String passwordValue = password.getText().toString();
            if(userDatabase.checkUser(usernameValue, passwordValue));

            //TODO DELETE THIS INTENT AFTER DATABASE IS IMPLEMENTED
            //TODO INTENT WILL BE CALL AT verifyDatabaseData() FUNCTION
            //call the eventListActivity if data are valid
            Intent intent = new Intent(LoginActivity.this, ListEventsActivity.class);
            startActivity(intent);
            //close this activity
            this.finish();
        }else {
            Toast toast = Toast.makeText(this, "Wrong email or password!", Toast.LENGTH_LONG);
        }
    }

    private boolean isEmail(EditText username) {
        CharSequence email = username.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }
    boolean isEmpty(EditText editText){
        CharSequence str = editText.getText().toString();
        return TextUtils.isEmpty(str);
    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        username.setText(null);
        password.setText(null);
    }

    private void verifyDatabaseData(){
//        if(userDatabase.checkUser(username.getText().toString().trim(), password.getText().toString().trim()));
//
//        Intent intent = new Intent(activity, EventListActivity.class);
//        startActivity(intent);
//        //close this activity
//        this.finish();


    }

}



