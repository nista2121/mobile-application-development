package com.nista.mobile2app_stanislas_mbengue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class ListEventsActivity extends AppCompatActivity {


    private EventDatabase eventDatabase;
    private ListView eventListView;
    private Button btnViewAll;
    private Button btnAdEvent;
    private List<Event> events;
    private Event event;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_events);

        btnViewAll = findViewById(R.id.btn_view_all_events);
        btnAdEvent = findViewById(R.id.btn_add_event_to_listView);
        eventListView = findViewById(R.id.listview_events);
        //initialize event
        event = new Event();
        //initialize the database
        eventDatabase = new EventDatabase(ListEventsActivity.this);


        //add event
        btnAdEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ListEventsActivity.this, AddEventActivity.class);
                startActivity(intent);
            }
        });
        //display all event
        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                events = eventDatabase.getAllEvent();
                ArrayAdapter eventAdapter = new ArrayAdapter<Event>(ListEventsActivity.this, android.R.layout.simple_list_item_1,events);
                //Toast.makeText(ListUserActivity.this, allUser.toString(), Toast.LENGTH_LONG).show();
                eventListView.setAdapter(eventAdapter);
            }
        });

        //delete an event
        eventListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Event eventClick = (Event) parent.getItemAtPosition(position);
                eventDatabase.deleteEvent(eventClick.getId());
                Toast.makeText(ListEventsActivity.this, eventClick + "was deleted successfully! ", Toast.LENGTH_LONG).show();
            }
        });
    }
}
