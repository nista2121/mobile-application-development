package com.nista.mobile2app_stanislas_mbengue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public class EventDatabase extends SQLiteOpenHelper {
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "event.db";

    //Create the first version of the database
    public EventDatabase(Context context){
        super(context, DATABASE_NAME, null, VERSION);

    }


    //call when the database is created the first time
    //contains code that create the database table
    //create event table with five column
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + EventTable.TABLE_EVENT + "( " +
               EventTable.COLUMN_EVENT_ID + "integer primary key autoincrement, " +
                EventTable.COLUMN_EVENT_NAME+ " text ,"+
                EventTable.COLUMN_EVENT_DESCRIPTION + " text, " +
                EventTable.COLUMN_EVENT_DATE + " date)" );
    }

    //call when the database need upgrading, contain code that drop the database,
    // transfer data from old table to new table
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + EventTable.TABLE_EVENT);
        //recreate the table
        onCreate(db);
    }

    //static inner class that define the table data
    private static final class EventTable implements BaseColumns {

        private static final String TABLE_EVENT = "events";
        private static final String COLUMN_EVENT_ID = "event_id";
        private static final String COLUMN_EVENT_NAME = "event_name";
        private static final String COLUMN_EVENT_DESCRIPTION = "event_description";
        private static final String COLUMN_EVENT_DATE= "event_date";
    }

    //add an event to the db
    public boolean addEvent(Event event){
        //get a writeable object from the SQLiteOpenHelper
        SQLiteDatabase db = this.getWritableDatabase();
        //create contentValue Object to hold the table columns and associated data
        ContentValues contentValues = new ContentValues();
        contentValues.put(EventTable.COLUMN_EVENT_NAME, event.getEventName() );
        contentValues.put(EventTable.COLUMN_EVENT_DESCRIPTION, event.getDescription());
        contentValues.put(EventTable.COLUMN_EVENT_DATE, String.valueOf(event.getEventDate()));

        long id = db.insert(EventTable.TABLE_EVENT, null, contentValues);
       if(id == - 1) {
           return false;
       }else {
           return true;
       }
    }

    //retrieve an event from the db
    public Event  getEventByName(String name){
        //get a readable object
        SQLiteDatabase db = getReadableDatabase();
        //create a string query to select the data
        String sql = "select * from " + EventTable.TABLE_EVENT + " where name = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {String.valueOf(name)});

        if (cursor != null)
            cursor.moveToFirst();

        Event eventName = new Event(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2), (cursor.getString(3)));
        //close the cursor
        cursor.close();
        // return user
        return eventName;
    }

    //select all event
public List<Event> getAllEvent(){
        //create an array of column to fetch
    String[] columns = {
            EventTable.COLUMN_EVENT_ID,
            EventTable.COLUMN_EVENT_NAME,
            EventTable.COLUMN_EVENT_DESCRIPTION,
            EventTable.COLUMN_EVENT_DATE
    };
    //sort them by Date
    String sortOrder = EventTable.COLUMN_EVENT_DATE + "ASC";
    List<Event> eventList = new ArrayList<>();
    SQLiteDatabase db = this.getReadableDatabase();

    Cursor cursor = db.query(
            EventTable.TABLE_EVENT, // Table name
            columns, // columns to return
            null, // selection where the where clause
            null, //value for the where the close
            null, // group the row
            null, //filter by row
            sortOrder //sort the column in ascending order
    );
    //Traverse through all the row and add them to the list
    if(cursor.moveToFirst()){
        do{
            //TODO
        }while(cursor.moveToNext());

    }
    cursor.close();
    return eventList;

}
    //update an event
    public boolean updateEvent(int id, Event event){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EventTable.COLUMN_EVENT_NAME, event.getEventName());
        contentValues.put(EventTable.COLUMN_EVENT_DESCRIPTION, event.getDescription());
        contentValues.put(EventTable.COLUMN_EVENT_DATE, String.valueOf(event.getEventDate()));
        int rowsUpdated = db.update(EventTable.TABLE_EVENT, contentValues, "_id = ? ", new String[] {Float.toString(id)});
        return  rowsUpdated > 0;
    }
    //delete and event
public boolean deleteEvent(long id){
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(EventTable.TABLE_EVENT, EventTable.COLUMN_EVENT_ID + " = ? ", new String[] { Long.toString(id)});
        return rowsDeleted > 0;
}




}
