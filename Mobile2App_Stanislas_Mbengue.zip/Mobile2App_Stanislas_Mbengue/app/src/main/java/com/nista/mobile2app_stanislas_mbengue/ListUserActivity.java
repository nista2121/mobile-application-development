package com.nista.mobile2app_stanislas_mbengue;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class ListUserActivity extends AppCompatActivity {

    private UserDatabase userDatabase;
    private ListView listView_user;
    private Button btnViewAll;

    List<User> allUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.avtivity_user_list);
        btnViewAll = findViewById(R.id.btn_view_all);
        listView_user = findViewById(R.id.listview_userList);

        //initialize the database
        userDatabase = new UserDatabase(ListUserActivity.this);

        btnViewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allUser = userDatabase.getAllUser();
                ArrayAdapter userAdapter = new ArrayAdapter<User>(ListUserActivity.this,  android.R.layout.simple_list_item_1, allUser);
               //Toast.makeText(ListUserActivity.this, allUser.toString(), Toast.LENGTH_LONG).show();
                listView_user.setAdapter(userAdapter);
            }
        });
listView_user.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        User userClick = (User) parent.getItemAtPosition(position);
        userDatabase.deleteUser(userClick);
        Toast.makeText(ListUserActivity.this, "Deletion successfull! ", Toast.LENGTH_LONG).show();

    }
});

    }
}