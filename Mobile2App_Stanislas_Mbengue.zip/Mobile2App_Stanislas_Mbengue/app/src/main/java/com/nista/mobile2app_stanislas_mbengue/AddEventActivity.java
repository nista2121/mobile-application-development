package com.nista.mobile2app_stanislas_mbengue;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddEventActivity extends AppCompatActivity {

    private Button btnAddEvent;
    private EditText eventName;
    private EditText eventDate;
    private EditText eventTime;
    private EditText eventDescription;

    private EventDatabase eventDatabase;
    private Event event;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        btnAddEvent = findViewById(R.id.addEvent);
        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventTime = findViewById(R.id.eventTime);
        eventDescription= findViewById(R.id.eventDescription);

        //initialize the database
        eventDatabase = new EventDatabase(AddEventActivity.this);
        btnAddEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = eventName.getText().toString();
                String date =  eventDate.getText().toString();
                String time = eventTime.getText().toString();
                String description = eventDescription.getText().toString();

                event = new Event(name, description, date);
                eventDatabase.addEvent(event);
                Toast.makeText(AddEventActivity.this, "Event was added successfully!" , Toast.LENGTH_LONG).show();

                Intent intent = new Intent(AddEventActivity.this, ListEventsActivity.class);
                startActivity(intent);
            }
        });
    }
}