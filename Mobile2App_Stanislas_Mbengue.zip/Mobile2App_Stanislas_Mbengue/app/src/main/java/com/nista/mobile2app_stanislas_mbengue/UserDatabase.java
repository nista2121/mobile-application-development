package com.nista.mobile2app_stanislas_mbengue;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;

import java.util.ArrayList;
import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "user.db";

    UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);

    }

    //create a user table
    private static final class UserTable implements BaseColumns {

        private static final String TABLE_USER = "users";
        private static final String COLUMN_USER_ID = "user_id";
        private static final String COLUMN_USER_NAME = "user_name";
        private static final String COLUMN_USER_EMAIL = "user_email";
        private static final String COLUMN_USER_PASSWORD = "user_password";
    }

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + UserTable.TABLE_USER + " (" +
                    UserTable.COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    UserTable.COLUMN_USER_NAME + " TEXT," +
                    UserTable.COLUMN_USER_EMAIL + " TEXT," +
                    UserTable.COLUMN_USER_PASSWORD + " TEXT )";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + UserTable.TABLE_USER;


    @Override
    public void onCreate(SQLiteDatabase db) {
        //create table and pass the String SQL query
        db.execSQL(SQL_CREATE_ENTRIES);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop UserTable if exist
        db.execSQL(SQL_DELETE_ENTRIES);

        // Create Usertable again
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    //add a new user
    public boolean addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COLUMN_USER_NAME, user.getName());
        values.put(UserTable.COLUMN_USER_EMAIL, user.getEmail());
        values.put(UserTable.COLUMN_USER_PASSWORD, user.getPassword());

        long id = db.insert(UserTable.TABLE_USER, null, values);
        db.close();
        if(id == -1){
            return false;
        }else{
            return true;
        }


    }

    //update user in the database on the base on email
    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.COLUMN_USER_NAME, user.getName());
        values.put(UserTable.COLUMN_USER_EMAIL, user.getEmail());
        values.put(UserTable.COLUMN_USER_PASSWORD, user.getPassword());

        db.update(UserTable.TABLE_USER, values, UserTable.COLUMN_USER_NAME + " = ? ", new String[]{String.valueOf(user.getName())});
        db.close();

    }

    // code to get the single user
    public User getUser(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(UserTable.TABLE_USER, new String[] { UserDatabase.DATABASE_NAME,
                        UserTable.COLUMN_USER_ID, UserTable.TABLE_USER}, UserTable.COLUMN_USER_EMAIL + "=?",
                new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        User user = new User(Integer.parseInt(cursor.getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3));
        // return user
        return user;
    }

    /**
     * Check if user exist in the database base of the email address or not
     * @param email
     * @return true if user exist, otherwise return false
     */
    public boolean checkUser(String email) {
        // array of columns to fetch
        String[] columns = { UserTable.COLUMN_USER_ID };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = UserTable.COLUMN_USER_EMAIL + " = ?";
        // selection argument
        String[] selectionArgs = {email};
        // query user table with condition
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'example@example.com';
         */
        Cursor cursor = db.query(UserTable.TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    /**
     * Check if user email and password exist
     * @param email
     * @param password
     * @return
     */
    public boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = { UserTable.COLUMN_USER_ID };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = UserTable.COLUMN_USER_EMAIL + " = ?" + " AND " + UserTable.COLUMN_USER_PASSWORD + " = ?";
        // selection arguments
        String[] selectionArgs = {email, password};

        // query user table with conditions
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id FROM user WHERE user_email = 'example@example.com' AND user_password = 'password123';
         */
        Cursor cursor = db.query(UserTable.TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }
        return false;
    }

    public List<User> getAllUser(){
        List<User> userList = new ArrayList<>();
        //get data from the db
        String stringQuery = "SELECT * FROM " + UserTable.TABLE_USER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(stringQuery, null);

        if(cursor.moveToFirst()){
            do{
               //loop through the cursor(result set)and create a new customer and put it to the list
                User user = new User();
                user.setId( cursor.getInt(0));
                user.setName(cursor.getString(1));
                user.setEmail(cursor.getString(2));
                user.setPassword(cursor.getString(3));

                userList.add(user);
            }while(cursor.moveToNext());
        }else{

        }
        cursor.close();
        db.close();
        return userList;
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(UserTable.TABLE_USER, UserTable.COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }
}
